package com.example.mypar.gift.Service;

/**
 * Created by watoz on 2018-05-17.
 */

public class Constants {
    public static final String STORAGE_PATH_UPLOADS = "pdf/";
    public static final String DATABASE_PATH_UPLOADS = "pdf";
}
