package com.example.mypar.gift.Model;

/**
 * Created by seki on 2018-04-02.
 */

class Result {
    public String message_id ;
}

