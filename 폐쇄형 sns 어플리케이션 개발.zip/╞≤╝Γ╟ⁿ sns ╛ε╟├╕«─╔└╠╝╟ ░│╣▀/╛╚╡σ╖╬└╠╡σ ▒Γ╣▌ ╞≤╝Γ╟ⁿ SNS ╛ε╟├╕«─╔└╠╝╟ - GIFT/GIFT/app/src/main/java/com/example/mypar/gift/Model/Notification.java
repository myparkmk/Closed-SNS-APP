package com.example.mypar.gift.Model;

/**
 * Created by seki on 2018-04-02.
 */

public class Notification {
    public String body ;
    public String title;

    public Notification(String body, String title) {
        this.body = body;
        this.title = title;
    }
}
