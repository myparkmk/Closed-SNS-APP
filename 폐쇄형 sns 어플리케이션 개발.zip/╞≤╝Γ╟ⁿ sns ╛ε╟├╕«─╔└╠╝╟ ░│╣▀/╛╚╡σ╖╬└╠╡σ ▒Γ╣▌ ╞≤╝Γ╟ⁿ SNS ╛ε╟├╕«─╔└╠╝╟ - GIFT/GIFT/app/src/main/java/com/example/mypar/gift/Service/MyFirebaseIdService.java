package com.example.mypar.gift.Service;

import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by seki on 2018-03-29.
 */

public class MyFirebaseIdService extends FirebaseInstanceIdService{

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();


    }
}
